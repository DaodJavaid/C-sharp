﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        string user = "abc";
        string pass = "123";
        private void button1_Click(object sender, EventArgs e)
        {

            this.Hide();
            // Show New Form

            if ((textBox1.Text == user) && (textBox2.Text == pass))
            {
                Afterloginemployer Afterloginemployer = new Afterloginemployer();
                Afterloginemployer.Show();
            }
            else
            {
                MessageBox.Show("Your Email and Password Wrong");
            }
        }
    }
}
