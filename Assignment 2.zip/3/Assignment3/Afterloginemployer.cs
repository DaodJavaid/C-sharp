﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Assignment3
{
    public partial class Afterloginemployer : Form
    {
        public Afterloginemployer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login backLogin = new Login();
            backLogin.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamWriter A = new StreamWriter(Application.StartupPath + "\\txtFiles\\" + (textBox2.Text) + ".txt");

            A.Write(richTextBox3Files.Text);
            A.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox3Files.Clear();
            textBox2.Clear();
        }
    }
}
